<?php
$id = $_POST['model'];

if ($id==1) 
{
	header("Location:model.php");
}

else if($id==2)
{
	header("Location:model1.php");
}

else if($id==3)
{
	header("Location:model2.php");
}
else if($id==4)
{
	header("Location:model3.php");
}
else if($id==5)
{
	header("Location:model4.php");
}
else if($id==6)
{
	header("Location:model5.php");
}



?>
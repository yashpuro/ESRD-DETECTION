-- MySQL dump 10.13  Distrib 5.7.15, for Win64 (x86_64)
--
-- Host: localhost    Database: cancer
-- ------------------------------------------------------
-- Server version	5.7.15-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `auth`
--

DROP TABLE IF EXISTS `auth`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth` (
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth`
--

LOCK TABLES `auth` WRITE;
/*!40000 ALTER TABLE `auth` DISABLE KEYS */;
INSERT INTO `auth` VALUES ('subh','subh@subh.com','abc');
/*!40000 ALTER TABLE `auth` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `graphs_location`
--

DROP TABLE IF EXISTS `graphs_location`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `graphs_location` (
  `desc` varchar(50) NOT NULL,
  `path` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `graphs_location`
--

LOCK TABLES `graphs_location` WRITE;
/*!40000 ALTER TABLE `graphs_location` DISABLE KEYS */;
/*!40000 ALTER TABLE `graphs_location` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `head`
--

DROP TABLE IF EXISTS `head`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `head` (
  `Patient Id` varchar(11) NOT NULL,
  `Smoking Habbits` int(3) NOT NULL,
  `Drinking Habbits` int(3) NOT NULL,
  `Occupational Exposure` int(3) NOT NULL,
  `UV Radiation` int(3) NOT NULL,
  `Alchohal` int(3) NOT NULL,
  `Age` int(3) NOT NULL,
  `Sex` int(3) NOT NULL,
  `Genetics` int(3) NOT NULL,
  `Reproductive Factors` int(3) NOT NULL,
  `Estrogen` int(3) NOT NULL,
  `Life Style` int(3) NOT NULL,
  `# of Children` int(3) NOT NULL,
  `Race` int(3) NOT NULL,
  `Harmonal Imbalance` int(3) NOT NULL,
  `Heamoglobin Qunatity` int(3) NOT NULL,
  `Cancer Types` int(3) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `head`
--

LOCK TABLES `head` WRITE;
/*!40000 ALTER TABLE `head` DISABLE KEYS */;
INSERT INTO `head` VALUES ('Pat00001',1,0,2,4,0,24,0,13,31,55,23,2,1,0,4,2);
/*!40000 ALTER TABLE `head` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `model_details`
--

DROP TABLE IF EXISTS `model_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `model_details` (
  `model_id` int(5) NOT NULL,
  `accuracy` float NOT NULL,
  `error1` float NOT NULL,
  `error2` float NOT NULL,
  `roc_auc` float NOT NULL,
  `confusion_matrix1` int(10) NOT NULL,
  `confusion_matrix2` int(10) NOT NULL,
  `confusion_matrix3` int(10) NOT NULL,
  `confusion_matrix4` int(10) NOT NULL,
  PRIMARY KEY (`model_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `model_details`
--

LOCK TABLES `model_details` WRITE;
/*!40000 ALTER TABLE `model_details` DISABLE KEYS */;
INSERT INTO `model_details` VALUES (14828,20,0,0,0,0,0,0,0);
/*!40000 ALTER TABLE `model_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prediction`
--

DROP TABLE IF EXISTS `prediction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `prediction` (
  `Patient Id` varchar(11) NOT NULL,
  `Smoking Habbits` int(3) NOT NULL,
  `Drinking Habbits` int(3) NOT NULL,
  `Occupational Exposure` int(3) NOT NULL,
  `UV Radiation` int(3) NOT NULL,
  `Alchohal` int(3) NOT NULL,
  `Age` int(3) NOT NULL,
  `Sex` int(3) NOT NULL,
  `Genetics` int(3) NOT NULL,
  `Reproductive Factors` int(3) NOT NULL,
  `Estrogen` int(3) NOT NULL,
  `Life Style` int(3) NOT NULL,
  `# of Children` int(3) NOT NULL,
  `Race` int(3) NOT NULL,
  `Harmonal Imbalance` int(3) NOT NULL,
  `Heamoglobin Qunatity` int(3) NOT NULL,
  `Cancer Types` int(3) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prediction`
--

LOCK TABLES `prediction` WRITE;
/*!40000 ALTER TABLE `prediction` DISABLE KEYS */;
INSERT INTO `prediction` VALUES ('a',1,1,1,1,1,1,1,11,1,1,1,1,1,1,1,1);
/*!40000 ALTER TABLE `prediction` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-03-26  0:50:55

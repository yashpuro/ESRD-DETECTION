<html><head><title>MySQL Table Viewer</title>
<link rel="stylesheet" href="css/bootstrap.css"></head><body>

<?php
// include ('config.php');
// // sending query
// $mid = $_POST["model"];

// $result = mysqli_query($db,"SELECT * FROM model_details where model_id='$mid'");
// if (!$result) {
//     die("Query to show fields from table failed");
// }
// echo "<center>";

echo "<h1 class='display-3' style='text-align: center;' > Details </h1>";

// // printing table rows
// while($row = mysqli_fetch_array($result))
// {
//  $m1=$row['confusion_matrix1'];
//     $m2=$row['confusion_matrix2'];
//     $m3=$row['confusion_matrix3'];
//     $m4=$row['confusion_matrix4'];
   
//     $mid=$row['model_id'];
//     $acc=$row['accuracy'];
//     $err=$row['error1'];
//     $err1=$row['error2'];
//     $roc_auc=$row['roc_auc'];


//     // $row is array... foreach( .. ) puts every element
//     // of $row to $cell variable
 
    


//     echo "</tr>\n";
// }
// mysqli_free_result($result);

echo "<div'><div class='card border-success mb-3' style='height:220px; width:200px; margin-left: auto; margin-right: auto; margin-top: 50px;'>
  <div class='card-header'>Model Name</div
  <div class='card-body'>
    
    <h2 class='card-text'><h3> X-G Boost Classifier </h3></h2>
  </div></div>";
echo "<div class='card border-success mb-3' style='height:220px; width:200px; margin-left: auto; margin-right: auto;'>
  <div class='card-header'>Accuracy</div>
  <div class='card-body'>
    
    <h1 class='card-text'>82.02%</h1>
  </div></div>";

  echo "<div class='card border-success mb-3' style=' height:220px; width:200px; margin-left: auto; margin-right: auto;'>
  <div class='card-header'>Errors</div>
  <div class='card-body'>
    
    <p class='card-text'><p>Precision average: 0.80</p><p>recall average:0.82</p><p>f1-score average:0.80</p><p>Support average:9000</p></p>
  </div></div>";

echo "<div class='card border-success mb-3' style=' height:220px; width:200px; margin-left: auto; margin-right: auto;'>
  <div class='card-header'>Confusion Matrix</div>
  <div class='card-body'>
    
    <p class='card-text'>
    <table width='100%' border=1;  bordercolor='white';left:0;>
  <tr>
    <td>6660</td>
    <td>340</td>
    
  </tr>
  <tr>
    <td>1278</td>
    <td>722</td>
    
  </tr>
  </table></p>
  </div></div></div>";
echo "</center>";
?>
</body></html>         
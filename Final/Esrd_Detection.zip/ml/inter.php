<?php  
$result = $_POST["SM"];
$result1 = $_POST["DH"];
$result2 = $_POST["PT"];
$result3 = $_POST["VA"];
$result4 = $_POST["UA"];
if(isset($result))
{
	header("Location:SM.html");
}

elseif (isset($result1)) 
{
	header("Location:main.php");	
}
elseif (isset($result2)) 
{
	header("Location:PT.html");	
}
elseif (isset($result3)) 
{
	header("Location:details.html");	
}
elseif (isset($result4)) 
{
	header("Location:details.html");	
}
//background-image: url(back.jpg);
?>
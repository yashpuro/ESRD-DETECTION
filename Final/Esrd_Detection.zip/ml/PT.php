<?php  
include("config.php");
 if($_SERVER["REQUEST_METHOD"] == "POST")
 {
 	//$f1 =$_POST['f1'];
 	$f2 =$_POST['f2'];
 	$f3 =$_POST['f3'];
 	$f4 =$_POST['f4'];
 	$f5 =$_POST['f5'];
 	$f6 =$_POST['f6'];
 	$f7 =$_POST['f7'];
 	$f8 =$_POST['f8'];
 	$f9 =$_POST['f9'];
 	$f10 =$_POST['f10'];
 	$f11 =$_POST['f11'];
 	$f12 =$_POST['f12'];
 	$f13 =$_POST['f13'];
 	$f14 =$_POST['f14'];
 	$f15 =$_POST['f15'];
 	$f16 =$_POST['f16'];
 	//$f17 =$_POST['f17'];

echo "<h1>OOPS!!</h1>";
echo "<a href='tabs.php'>Go back</a>";

	$sql = "INSERT INTO prediction VALUES ($f2,$f3,$f4,$f5,$f6,$f7,$f8,$f9,$f10,$f11,$f12,$f13,$f14,$f15,$f16,NULL)";
	$sql1="select * from prediction";
	 $result = mysqli_query($db,$sql1);
               $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
               $count = mysqli_num_rows($result);
               if($count >0)
               {
               	echo "<script>alert('Previous prediction not completed');</script>";
               }


else{
	if ($db->query($sql) === TRUE) 
{
  echo "<script> alert('prediction table added successfully'); </script>";
 
  header("location: main.html");
}
 else
  {
  	// echo "<script> alert('connection failed'); </script>";
  	echo "Error: " . $sql . "<br>" . $db->error;
  }}

	

 }


?>
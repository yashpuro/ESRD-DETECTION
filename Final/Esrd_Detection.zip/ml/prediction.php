<html><head><title>MySQL Table Viewer</title>
<link rel="stylesheet" href="css/bootstrap.css"></head><body>
	<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="#"></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarColor02" aria-controls="navbarColor02" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarColor02">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="http://localhost/ml/main.html"style="background-color: #00bc8c"> <span class="sr-only">(current)</span></a>
      </li>
      
    </ul>
  
    
  
  </div>
</nav>
<br><br>
<?php
include ('config.php');
// sending query


$result = mysqli_query($db,"SELECT * FROM prediction");
if (!$result) {
    die("Query to show fields from table failed");
}
echo "<center>";


// printing table rows
while($row = mysqli_fetch_array($result))
{
	$m1=$row['ESRD_Disease'];
   

    // $row is array... foreach( .. ) puts every element
    // of $row to $cell variable
 
    


    echo "</tr>\n";
}
mysqli_free_result($result);

echo "<div class='card border-success mb-3' style='max-width: 20rem;''>
  <div class='card-header'>Prediction</div>
  <div class='card-body'>
    
    <p class='card-text'>$m1</p>
  </div>";


echo "</center>";

$sql = "truncate prediction;";

if($db->query($sql))
{

}



?>
</body></html>